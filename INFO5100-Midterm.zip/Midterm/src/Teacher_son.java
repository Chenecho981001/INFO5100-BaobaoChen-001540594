public class Teacher_son extends Teacher{
    public void teach(){
        System.out.println("teacher is teaching class now");
    }

}
