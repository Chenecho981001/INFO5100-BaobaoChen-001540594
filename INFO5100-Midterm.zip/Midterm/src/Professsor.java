public interface Professsor {

     public  void teach();
}
