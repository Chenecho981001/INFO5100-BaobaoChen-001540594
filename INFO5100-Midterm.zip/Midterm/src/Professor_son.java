public class Professor_son implements  Professsor{

    public void teach(){
        System.out.println("professor is teaching the class");
    }



}
